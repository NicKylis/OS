#!/bin/bash
date
current_time=$ date +%s
echo "$current_time"
let current_time=current_time*2
echo "$current_time"
for((i=1; i<21; i++)); do
echo "$i"
done
